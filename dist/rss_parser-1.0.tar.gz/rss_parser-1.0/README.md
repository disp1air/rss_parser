How to run a unit test:

    coverage run -m unittest test_convert_module.py 

How to check its coverage:

    coverage report -m